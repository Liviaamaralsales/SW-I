<h1>Editar Marcas</h1>

<form action="?page=salvar-modelos" method="post">
    <input type="hidden" name="acao" value="editar">
    

    <div>
        <div class="container mb-3">
            <label for="mt-3">Marca</label>
            <input type="text" name="marca" class="form-control" placeholder="digite seu nome">
        </div>

        <div class="container mb-3">
            <label for="mt-3">Modelo</label>
            <input type="text" name="marca" class="form-control" placeholder="digite seu nome">
        </div>

        <div class="container mb-3">
            <label for="mt-3">Ano</label>
            <input type="text" name="marca" class="form-control" placeholder="digite seu nome">
        </div>

        <div class="container mb-3">
            <label for="mt-3">Cor</label>
            <input type="text" name="marca" class="form-control" placeholder="digite seu nome">
        </div>

        <div class="container mb-3">
            <label for="mt-3">Placa</label>
            <input type="text" name="marca" class="form-control" placeholder="digite seu nome">
        </div>
        
        <div class="container mb-3">
            <button type="sumit" class="btn btn-primary">Editar</button>
        </div>
    </div>
</form>