<h1>Cadastrar Marcas</h1>

<form action="?page=salvar-marcvas" method="post">
    <input type="hidden" name="acao" value="cadastrar">
    

    <div>
        <div class="container mb-3">
            <label for="mt-3">Marca</label>
            <input type="text" name="marca" class="form-control" placeholder="digite seu nome">
        </div>

        <div class="container mb-3">
            <button type="sumit" class="btn btn-primary">cadastrar</button>
        </div>
    </div>
</form>