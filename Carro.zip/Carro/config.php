<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DBBASE', 'carro');

$conn = new mysqli(HOST, USER, PASS, DBBASE);

if ($conn->connerct_error) {
    echo "Não conectado.$conn->connect_error";
}else {
    # echo "Banco conectado";
}
?>